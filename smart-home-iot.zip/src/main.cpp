#include "RMaker.h"
#include "WiFi.h"
#include "WiFiProv.h"
#include "DHT.h"

#define LED_R 2
#define LED_G 3
#define LED_B 4
#define LED_AC 7
#define PIR 6
#define DHTPIN 5

#define DHTTYPE DHT11

DHT dht(DHTPIN, DHTTYPE);

bool lightState = false;
int brightness = 128;

Device *light;

void write_callback(Device *device, Param *param, const param_val_t val) {
    const char *param_name = param->getParamName();

    if (strcmp(param_name, "Power") == 0) {
        lightState = val.val.b;
        digitalWrite(LED_R, lightState);
    }

    if (strcmp(param_name, "Brightness") == 0) {
        brightness = val.val.i;
        analogWrite(LED_R, brightness);
    }
}

void setup() {
    Serial.begin(115200);

    pinMode(LED_R, OUTPUT);
    pinMode(LED_G, OUTPUT);
    pinMode(LED_B, OUTPUT);
    pinMode(LED_AC, OUTPUT);
    pinMode(PIR, INPUT);

    dht.begin();

    Node my_node;
    light = new Device("Luz", "esp.device.light", NULL);
    light->addCb(write_callback);

    light->addParam("Power", true);
    light->addParam("Brightness", brightness);

    my_node.addDevice(*light);

    RMaker.start();
    WiFiProv.beginProvision(WIFI_PROV_SCHEME_BLE);
}

void loop() {
    float temp = dht.readTemperature();
    float hum = dht.readHumidity();

    if (temp > 28) {
        digitalWrite(LED_AC, HIGH);
    } else {
        digitalWrite(LED_AC, LOW);
    }

    int motion = digitalRead(PIR);
    if (motion == HIGH) {
        digitalWrite(LED_R, HIGH);
    }

    delay(2000);
}
